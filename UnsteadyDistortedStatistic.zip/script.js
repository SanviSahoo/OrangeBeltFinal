<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game</title>
</head>
<body>
    <h1>Welcome to the Game Page!</h1>
    <p>This is the game page of our website.</p>
    <p>Feel free to navigate to other pages.</p>
    <img src="Image.jpg" alt="Game Image">
    <nav>
        <a href="home.html">Go to Home Page</a>
        <a href="index.html">Go to Index Page</a>
        <a href="picture.html">Go to Picture Page</a>
    </nav>
</body>
</html>

        